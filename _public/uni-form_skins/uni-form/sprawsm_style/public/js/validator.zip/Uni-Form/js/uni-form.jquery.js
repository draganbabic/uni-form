jQuery.fn.uniform = function(settings) {
  settings = jQuery.extend({
    valid_class    : 'valid',
    invalid_class  : 'invalid',
    focused_class  : 'focused',
    holder_class   : 'ctrlHolder',
    field_selector : 'input, select, textarea'
  }, settings);
  
  return this.each(function() {
    var form = jQuery(this);
    var form_id = form.attr('id');
    if(!form_id) {
      form_id = 'UniFormForm' + jQuery.fn.uniform.formCounter;
      form.attr('id', form_id);
      jQuery.fn.uniform.formCounter++;
    } // if
    
    // Prepare form objects
    jQuery.fn.uniform.validation[form_id] = {};
    jQuery.fn.uniform.validationTimers[form_id] = {};
    jQuery.fn.uniform.focusedFields[form_id] = {};
    jQuery.fn.uniform.focusTimers[form_id] = {};
    
    // Nothing in this form has been changed just yet
    form[0].fieldValueUpdated = false;
    form.submit(function() {
      form[0].fieldValueUpdated = false; 
    });
    
    if(form.attr('class').indexOf('askOnLeave') != -1) {
      jQuery.fn.uniform.addBeforeUnloadEvent(function() {
        if(form[0].fieldValueUpdated) {
          return 'All changes you have made to this page will be lost!';
        } // if
      });
    } // if
    
    // Walk through defined validators and maku sure that they do their trick
    for(validator in jQuery.fn.uniform.validators) {
      form.find('.' + validator).each(function() {
        var field = $(this);
        var field_name = field.attr('name');
        
        if(typeof jQuery.fn.uniform.validation[form_id][field_name] != 'object') {
          jQuery.fn.uniform.validation[form_id][field_name] = {
            'field' : field,
            'field_caption' : jQuery.fn.uniform.fieldName(form.find('label[@for=' + field.attr('id') + ']')),
            'validators' : {}
          };
        } // if
        
        jQuery.fn.uniform.validation[form_id][field_name].validators[validator] = jQuery.fn.uniform.validators[validator];
      });
    } // for
    
    // Make sure that form submission is disabled if we don't have all data
    jQuery.fn.uniform.validateForm(form_id);
    
    /**
     * Change handler for field change in this form
     */
    var field_change_handler = function() {
      var field_name = jQuery(this).attr('name');
      
      form[0].fieldValueUpdated = true;
      
      if(jQuery.fn.uniform.isValidatedField(form_id, field_name)) {
        if(jQuery.fn.uniform.validationTimers[form_id][field_name]) {
          clearTimeout(jQuery.fn.uniform.validationTimers[form_id][field_name]);
        } // if
        jQuery.fn.uniform.validationTimers[form_id][field_name] = setTimeout("jQuery.fn.uniform.validateForm('" + form_id + "')", 500);
      } // if
    };
    
    var focus_first_field = form.attr('class').indexOf('focusFirstField') != -1;
    var first_field_focused = false;
    
    // Select all fields and do something with them
    form.find(settings.field_selector).each(function() {
      var field = jQuery(this);
      
      if(focus_first_field && !first_field_focused) {
        field[0].focus();
        first_field_focused = true;
        
        jQuery.fn.uniform.focusField(field, form_id);
      } // if
      
      // Make sure that focused field are marked and that we remember that this 
      // field was focused
      field.focus(function() {        
        jQuery.fn.uniform.focusField(jQuery(this), form_id);
      });
      
      // Notify form and validators on value change
      field.blur(field_change_handler);
      switch(field[0].nodeName.toUpper) {
        case 'SELECT':
          field.click(field_change_handler);
          break;
        default:
          field.keypress(field_change_handler);
      }
    });
  });
  
};

// Counter used for generating form IDs if they are not present
jQuery.fn.uniform.formCounter = 1;

// We'll store validation rules in this object
jQuery.fn.uniform.validation = {};

// Timers that are used to validate fields
jQuery.fn.uniform.validationTimers = {};

// Fields that received focus by user (only if a field previosly received focus 
// we will show error message for it)
jQuery.fn.uniform.focusedFields = {};

// Timers that will mark field as focused
jQuery.fn.uniform.focusTimers = {};

/**
 * Validate given form (based on form_id string)
 *
 * @param string form_id
 * @return boolean
 */
jQuery.fn.uniform.validateForm = function(form_id) {
  if(typeof jQuery.fn.uniform.validation[form_id] == 'object') {
    var all_valid = true;
    for(field_name in jQuery.fn.uniform.validation[form_id]) {
      if(!jQuery.fn.uniform.validateField(form_id, field_name)) {
        all_valid = false;
      } // if
    } // for
    
    if(all_valid) {
      jQuery('#' + form_id).find('button[@type=submit]').attr('disabled', '');
    } else {
      jQuery('#' + form_id).find('button[@type=submit]').attr('disabled', 'disabled');
    } // if
  } // if
  return false;
};

/**
 * Check if we need to validate this specific field in the form
 *
 * @param string form_id
 * @param string field_name
 */
jQuery.fn.uniform.isValidatedField = function(form_id, field_name) {
  return (typeof jQuery.fn.uniform.validation[form_id] == 'object') && (typeof jQuery.fn.uniform.validation[form_id][field_name] == 'object');
}

/**
 * Validate a specific field in a given form
 *
 * @param string form_id
 * @param string field_id
 * @return boolean
 */
jQuery.fn.uniform.validateField = function(form_id, field_name) {
  if(jQuery.fn.uniform.isValidatedField(form_id, field_name)) {
    var field = jQuery.fn.uniform.validation[form_id][field_name].field;
    var caption = jQuery.fn.uniform.validation[form_id][field_name].field_caption;
    var validators = jQuery.fn.uniform.validation[form_id][field_name].validators;
    
    // Lets remove errors...
    jQuery.fn.uniform.removeError(field);
    
    // Walk through validators
    for(var validator in validators) {
      var validation_result = validators[validator](field, caption, form_id);
      
      if(validation_result !== true) {
        if((typeof jQuery.fn.uniform.focusedFields[form_id] == 'object') && jQuery.fn.uniform.focusedFields[form_id][field_name] == true) {
          jQuery.fn.uniform.setError(field, validation_result);
        } // if
        
        return false;
      } // if
    } // for
  } // if
  
  return true;
};

/**
 * Focus field
 *
 * @param jQuery field
 */
jQuery.fn.uniform.focusField = function(field, form_id) {
  if(!jQuery.fn.uniform.focusedFields[form_id][field.attr('name')]) {
    setTimeout("jQuery.fn.uniform.markFieldAsFocused('" + form_id + "', '" + field.attr('name') + "')", 600);
  } // if
  
  var holder = jQuery.fn.uniform.findHolder(field);
  if(typeof holder == 'object') {
    if(holder.attr('class').indexOf('focused') == -1) {
      jQuery('#' + form_id).find('.' + 'focused').removeClass('focused'); // everything else should lose focus
      holder.addClass('focused'); // and we should focus this element
    } // if
  } // if
}

/**
 * Mark field as focused
 *
 * @param string form_id
 * @param string field_id
 * @return boolean
 */
jQuery.fn.uniform.markFieldAsFocused = function(form_id, field_name) {
  jQuery.fn.uniform.focusedFields[form_id][field_name] = true;
  
  // Kill the timeout if set
  if(jQuery.fn.uniform.focusTimers[form_id][field_name]) {
    clearTimeout(jQuery.fn.uniform.focusTimers[form_id][field_name]);
  } // if
} // function

/**
 * Predefined uniform validators
 */
jQuery.fn.uniform.validators = {
  
  /**
   * Check if value of specific field is present
   *
   * @param jQuery field
   * @param string caption
   */
  required : function(field, caption) {
    console.log(caption);
    if(field.val() == '') {
      return caption + ' value is required';
    } else {
      return true;
    }
  },
  
  /**
   * Validate is value of given field is shorter than supported
   *
   * @param jQuery field
   * @param sting caption
   */
  validate_minlength : function(field, caption) {
    var min_length = 0;
    var classes = field.attr('class').split(' ');
    
    for(var i = 0; i < classes.length; i++) {
      if(classes[i] == 'validate_minlength') {
        if((classes[i + 1] != 'undefined') && !isNaN(classes[i + 1])) {
          min_length = parseInt(classes[i + 1]);
          break;
        } // if
      } // if
    } // for
    
    if((min_length > 0) && (field.val().length < min_length)) {
      return caption + ' value should be at least ' + min_length + ' characters long';
    } else {
      return true;
    } // if
  },
  
  /**
   * Validate if field value is longer than allowed
   *
   * @param jQuery field
   * @param string caption
   */
  validate_maxlength : function(field, caption) {
    var max_length = 0;
    var classes = field.attr('class').split(' ');
    
    for(var i = 0; i < classes.length; i++) {
      if(classes[i] == 'validate_maxlength') {
        if((classes[i + 1] != 'undefined') && !isNaN(classes[i + 1])) {
          max_length = parseInt(classes[i + 1]);
          break;
        } // if
      } // if
    } // for
    
    if((max_length > 0) && (field.val().length > max_length)) {
      return caption + ' value should not be longer than ' + max_length + ' characters';
    } else {
      return true;
    } // if
  },
  
  /**
   * Make sure that field has same value as the value of target field
   *
   * @param jQuery field
   * @param string caption
   */
  validate_same_as : function(field, caption) {
    var classes = field.attr('class').split(' ');
    var target_field_name = '';
    
    for(var i = 0; i < classes.length; i++) {
      if(classes[i] == 'validate_same_as') {
        if(classes[i + 1] != 'undefined') {
          target_field_name = classes[i + 1];
          break;
        } // if
      } // if
    } // for
    
    if(target_field_name) {
      var target_field = jQuery('#' + target_field_name);
      if(target_field.length > 0) {
        var target_field_caption = jQuery.fn.uniform.fieldName(jQuery('label[@for=' + target_field_name + ']'));
        
        if(target_field.val() != field.val()) {
          return caption + ' value is expected to be same as value of ' + target_field_caption + ' field';
        } // if
      } // if
    } // if
    
    return true;
  },
  
  /**
   * Validate if provided value is valid email address
   *
   * @param jQuery field
   * @param string caption
   */
  validate_email : function(field, caption) {
    if(field.val().match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
      return true;
    } else {
      return caption + ' value is not a valid email address';
    }
  },
  
  /**
   * Validate if provided value is valid URL
   *
   * @param jQuery field
   * @param string caption
   */
  validate_url : function(field, caption) {
    if(field.val().match(/^(http|https|ftp):\/\/(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)(:(\d+))?\/?/i)) {
      return true;
    } else {
      return caption + ' value is not a valid URL';
    }
  }, 
  
  /**
   * Number is only valid value (integers and floats)
   *
   * @param jQuery field
   * @param string caption
   */
  validate_number : function(field, caption) {
    if(field.val().match(/(^-?\d\d*\.\d*$)|(^-?\d\d*$)|(^-?\.\d\d*$)/)) {
      return true;
    } else {
      return caption + ' value need to be a number';
    }
  },
  
  /**
   * Whole numbers are allowed
   *
   * @param jQuery field
   * @param string caption
   */
  validate_integer : function(field, caption) {
    if(field.val().match(/(^-?\d\d*$)/)) {
      return true;
    } else {
      return caption + ' value need to be a whole number';
    }
  },
  
  /**
   * Letters only
   *
   * @param jQuery field
   * @param string caption
   */
  validate_alpha : function(field, caption) {
    if(field.val().match(/^[a-zA-Z]+$/)) {
      return true;
    } else {
      return caption + ' value should contain only letters (without special characters or numbers)';
    }
  },
  
  /**
   * Letters and numbers
   *
   * @param jQuery field
   * @param string caption
   */
  validate_alphanum : function(field, caption) {
    if(field.val().match(/\W/)) {
      return caption + ' value should contain only numbers and letters (without special characters)';
    } else {
      return true;
    }
  }
  
};

/**
 * Return control holder for a given field
 *
 * @param jQuery field
 */
jQuery.fn.uniform.findHolder = function(field) {
  var parent = field.parent();
      
  while(typeof(parent) == 'object') {
    if(parent[0].nodeName == 'FORM') {
      return;
    } // if
    if(parent[0].className.indexOf('ctrlHolder') >= 0) {
      return parent;
    } // if
    parent = jQuery(parent.parent());
  } // while
  
  return;
};

/**
 * Extract field name from label (removes * before the name if present)
 *
 * @param jQuery label
 */
jQuery.fn.uniform.fieldName = function(label) {
  if(typeof label == 'object') {
    var text = label.text();
    console.log(text);
    if(text.substr(0, 1) == '*') {
      return text.substring(2);
    } else {
      return text;
    }
  } // if
}

/**
 * Display error for a given field
 *
 * @param jQuery field
 * @param string error
 */
jQuery.fn.uniform.setError = function(field, error) {
  jQuery.fn.uniform.removeError(field);
  var parent = jQuery.fn.uniform.findHolder(field);
  if(parent) {
    parent.addClass('error');
    parent.prepend('<p class="errorField"><strong>' + error +  '</strong></p>');
  } // if
};

/**
 * Remove all errors for a given field
 *
 * @params jQuery field
 */
jQuery.fn.uniform.removeError = function(field) {
  var parent = jQuery.fn.uniform.findHolder(field);
  if(parent) {
    parent.removeClass('error');
    parent.find('p.errorField').remove();
  } // if
};

/**
 * Add onbeforeunload handler function
 *
 * @param function func
 */
jQuery.fn.uniform.addBeforeUnloadEvent = function(func) {
  var oldOnBeforeUnload = window.onbeforeunload;
  if(typeof window.onbeforeunload != 'function') {
    window.onbeforeunload = func;
  } else {
    window.onbeforeunload = function() {
      oldOnBeforeUnload();
      func();
    } // function
  } // if
}


// Auto set on page load...
$(document).ready(function() {
  jQuery('form.uniForm').uniform();
});